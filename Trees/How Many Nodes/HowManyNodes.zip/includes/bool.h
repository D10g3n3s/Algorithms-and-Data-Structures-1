#ifndef BOOL_H
    #define BOOL_H

    #define bool int
    #define FALSE 0
    #define TRUE 1

#endif